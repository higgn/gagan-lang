# gagan/__init__.py
from .lexer import tokenize
from .parser import Parser
from .interpreter import Interpreter

__version__ = "0.2"